You'll find the students.csv and biglog.txt files in the Starting Workspace folder.
